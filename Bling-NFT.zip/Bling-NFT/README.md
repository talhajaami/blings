# Bling NFT

## Commands

### `yarn`
### `yarn run build`
### `yarn start`