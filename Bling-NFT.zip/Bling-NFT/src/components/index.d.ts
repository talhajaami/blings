export declare global {
  interface Window {
    __selected: string;
    __imageSelected: string;
    __selected2: string;
    __imageSelected2: string;
    __button: string;
  }
}
